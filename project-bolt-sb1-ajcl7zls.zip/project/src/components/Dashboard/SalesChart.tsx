import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { TrendingUp } from 'lucide-react';

interface SalesData {
  date: string;
  amount: number;
}

export default function SalesChart() {
  const [salesData, setSalesData] = useState<SalesData[]>([]);

  useEffect(() => {
    loadSalesData();
  }, []);

  const loadSalesData = async () => {
    const { data } = await supabase
      .from('sales')
      .select('sale_date, total_amount')
      .eq('status', 'completed')
      .order('sale_date', { ascending: true });

    if (data) {
      const aggregated = data.reduce((acc, sale) => {
        const date = sale.sale_date.split('T')[0];
        if (!acc[date]) {
          acc[date] = 0;
        }
        acc[date] += sale.total_amount;
        return acc;
      }, {} as Record<string, number>);

      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - (6 - i));
        return date.toISOString().split('T')[0];
      });

      const chartData = last7Days.map(date => ({
        date,
        amount: aggregated[date] || 0
      }));

      setSalesData(chartData);
    }
  };

  const maxAmount = Math.max(...salesData.map(d => d.amount), 1);

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-white text-lg font-semibold">Sales Trend</h3>
          <p className="text-gray-400 text-sm mt-1">Last 7 days</p>
        </div>
        <div className="bg-green-600/10 p-2 rounded-lg">
          <TrendingUp className="w-5 h-5 text-green-400" />
        </div>
      </div>

      <div className="space-y-4">
        {salesData.map((item, index) => {
          const percentage = maxAmount > 0 ? (item.amount / maxAmount) * 100 : 0;
          const date = new Date(item.date);
          const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });

          return (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400">{dayName}</span>
                <span className="text-white font-medium">${item.amount.toLocaleString()}</span>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-green-600 to-green-500 rounded-full transition-all duration-500"
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
