import { useState, useEffect, useRef } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Send, Bot, User, Loader } from 'lucide-react';

interface Message {
  id: string;
  message: string;
  response: string;
  created_at: string;
}

export default function ChatbotView() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadChatHistory();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadChatHistory = async () => {
    const { data } = await supabase
      .from('chat_history')
      .select('*')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
    }
  };

  const processQuery = async (query: string): Promise<string> => {
    const lowerQuery = query.toLowerCase();

    if (lowerQuery.includes('low') && (lowerQuery.includes('stock') || lowerQuery.includes('inventory'))) {
      const { data } = await supabase
        .from('products')
        .select('name, current_stock, min_stock_threshold')
        .lte('current_stock', supabase.raw('min_stock_threshold'))
        .eq('is_active', true);

      if (data && data.length > 0) {
        const list = data.map(p => `${p.name} (${p.current_stock} units)`).join(', ');
        return `I found ${data.length} products running low on stock: ${list}. You should consider restocking these items soon.`;
      }
      return 'Good news! All products are currently well-stocked.';
    }

    if (lowerQuery.includes('best') || lowerQuery.includes('top') || lowerQuery.includes('most')) {
      const { data: salesData } = await supabase
        .from('sales')
        .select('product_id, quantity, total_amount')
        .eq('status', 'completed');

      if (salesData) {
        const { data: products } = await supabase.from('products').select('id, name');

        if (products) {
          const productMap = products.reduce((acc, p) => {
            acc[p.id] = p.name;
            return acc;
          }, {} as Record<string, string>);

          const aggregated = salesData.reduce((acc, sale) => {
            const name = productMap[sale.product_id] || 'Unknown';
            if (!acc[name]) acc[name] = { quantity: 0, revenue: 0 };
            acc[name].quantity += sale.quantity;
            acc[name].revenue += sale.total_amount;
            return acc;
          }, {} as Record<string, { quantity: number; revenue: number }>);

          const sorted = Object.entries(aggregated)
            .sort((a, b) => b[1].revenue - a[1].revenue)
            .slice(0, 5);

          const list = sorted.map(([name, data]) =>
            `${name} (${data.quantity} units sold, $${data.revenue.toLocaleString()} revenue)`
          ).join(', ');

          return `Here are your top 5 best-selling products: ${list}`;
        }
      }
      return 'No sales data available yet.';
    }

    if (lowerQuery.includes('sales') && (lowerQuery.includes('today') || lowerQuery.includes('month'))) {
      const today = new Date().toISOString().split('T')[0];
      const query = supabase
        .from('sales')
        .select('total_amount, sale_date')
        .eq('status', 'completed');

      if (lowerQuery.includes('today')) {
        query.gte('sale_date', today);
      } else if (lowerQuery.includes('month')) {
        const monthStart = new Date();
        monthStart.setDate(1);
        query.gte('sale_date', monthStart.toISOString());
      }

      const { data } = await query;
      const total = (data || []).reduce((sum, s) => sum + s.total_amount, 0);
      const count = data?.length || 0;

      const period = lowerQuery.includes('today') ? 'today' : 'this month';
      return `You've had ${count} sales ${period}, generating $${total.toLocaleString()} in revenue. ${count > 0 ? `Average order value: $${(total / count).toFixed(2)}` : ''}`;
    }

    if (lowerQuery.includes('restock') || lowerQuery.includes('order')) {
      const { data } = await supabase
        .from('products')
        .select('name, current_stock, reorder_point, reorder_quantity')
        .lte('current_stock', supabase.raw('reorder_point'))
        .eq('is_active', true);

      if (data && data.length > 0) {
        const list = data.map(p =>
          `${p.name} (current: ${p.current_stock}, suggested order: ${p.reorder_quantity} units)`
        ).join(', ');
        return `${data.length} products need restocking: ${list}. Place orders soon to avoid stockouts.`;
      }
      return 'All products are above their reorder points. No immediate restocking needed.';
    }

    if (lowerQuery.includes('value') || lowerQuery.includes('worth')) {
      const { data } = await supabase
        .from('products')
        .select('current_stock, unit_price')
        .eq('is_active', true);

      if (data) {
        const totalValue = data.reduce((sum, p) => sum + (p.current_stock * p.unit_price), 0);
        return `Your total inventory value is $${totalValue.toLocaleString()}. This includes ${data.length} active products.`;
      }
    }

    if (lowerQuery.includes('alert') || lowerQuery.includes('notification')) {
      const { data } = await supabase
        .from('alerts')
        .select('*')
        .eq('is_resolved', false)
        .order('created_at', { ascending: false })
        .limit(5);

      if (data && data.length > 0) {
        const list = data.map(a => `${a.message} (${a.severity})`).join('; ');
        return `You have ${data.length} active alerts: ${list}`;
      }
      return 'No active alerts. Everything looks good!';
    }

    if (lowerQuery.includes('customer')) {
      const { data } = await supabase
        .from('customers')
        .select('*')
        .order('total_purchases', { ascending: false })
        .limit(5);

      if (data && data.length > 0) {
        const list = data.map(c => `${c.name} ($${c.total_purchases.toLocaleString()})`).join(', ');
        return `You have ${data.length} top customers: ${list}`;
      }
      return 'No customer data available yet.';
    }

    return "I can help you with questions about:\n• Low stock items ('Which products are running low?')\n• Top selling products ('What sold the most?')\n• Sales data ('How much did I sell today/this month?')\n• Restocking needs ('Do I need to restock?')\n• Inventory value ('What's my inventory worth?')\n• Alerts ('What are my active alerts?')\n• Customers ('Who are my top customers?')\n\nTry asking me one of these questions!";
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setLoading(true);

    try {
      const response = await processQuery(userMessage);

      const { data } = await supabase
        .from('chat_history')
        .insert([{
          user_id: user?.id,
          message: userMessage,
          response,
          context_data: {}
        }])
        .select()
        .single();

      if (data) {
        setMessages([...messages, data]);
      }
    } catch (error) {
      console.error('Error processing chat:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 h-full flex flex-col">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white mb-2">AI Assistant</h1>
        <p className="text-gray-400">Ask questions about your inventory, sales, and business data</p>
      </div>

      <div className="flex-1 bg-gray-900 border border-gray-800 rounded-xl flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center max-w-md">
                <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-4 rounded-2xl inline-block mb-4">
                  <Bot className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-white text-xl font-semibold mb-2">Ask Me Anything</h3>
                <p className="text-gray-400 mb-6">
                  I'm connected to your real business data. Ask about inventory, sales, customers, or forecasts!
                </p>
                <div className="space-y-2 text-left bg-gray-800 rounded-lg p-4">
                  <p className="text-gray-500 text-xs uppercase font-medium mb-2">Try asking:</p>
                  <button
                    onClick={() => setInput('Which products are running low?')}
                    className="w-full text-left px-3 py-2 bg-gray-900 hover:bg-gray-700 text-gray-300 rounded text-sm transition-all"
                  >
                    Which products are running low?
                  </button>
                  <button
                    onClick={() => setInput('What sold the most this month?')}
                    className="w-full text-left px-3 py-2 bg-gray-900 hover:bg-gray-700 text-gray-300 rounded text-sm transition-all"
                  >
                    What sold the most this month?
                  </button>
                  <button
                    onClick={() => setInput('Do I need to restock before summer?')}
                    className="w-full text-left px-3 py-2 bg-gray-900 hover:bg-gray-700 text-gray-300 rounded text-sm transition-all"
                  >
                    Do I need to restock before summer?
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <>
              {messages.map((msg) => (
                <div key={msg.id} className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-blue-600 p-2 rounded-lg flex-shrink-0">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 bg-gray-800 rounded-lg p-4">
                      <p className="text-white">{msg.message}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="bg-gradient-to-br from-purple-600 to-blue-600 p-2 rounded-lg flex-shrink-0">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 bg-gradient-to-br from-gray-800 to-gray-800/50 rounded-lg p-4 border border-gray-700">
                      <p className="text-gray-200 whitespace-pre-line">{msg.response}</p>
                      <p className="text-gray-500 text-xs mt-2">
                        Based on real-time data from your system
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex items-start gap-3">
                  <div className="bg-gradient-to-br from-purple-600 to-blue-600 p-2 rounded-lg flex-shrink-0">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 bg-gray-800 rounded-lg p-4">
                    <div className="flex items-center gap-2">
                      <Loader className="w-4 h-4 text-gray-400 animate-spin" />
                      <p className="text-gray-400">Analyzing your data...</p>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        <div className="border-t border-gray-800 p-4">
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about your inventory, sales, or business data..."
              disabled={loading}
              className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all disabled:opacity-50"
            />
            <button
              onClick={handleSend}
              disabled={loading || !input.trim()}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg transition-all shadow-lg shadow-blue-600/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Send className="w-5 h-5" />
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
