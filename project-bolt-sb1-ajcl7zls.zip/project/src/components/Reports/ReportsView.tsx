import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { FileText, Download, Calendar } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export default function ReportsView() {
  const { user } = useAuth();
  const [reportType, setReportType] = useState('inventory');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<any>(null);

  const generateReport = async () => {
    setLoading(true);
    try {
      let reportData: any = {};
      let summary = '';

      if (reportType === 'inventory') {
        const { data: products } = await supabase
          .from('products')
          .select('*')
          .eq('is_active', true);

        const totalValue = (products || []).reduce((sum, p) => sum + (p.current_stock * p.unit_price), 0);
        const lowStock = (products || []).filter(p => p.current_stock <= p.min_stock_threshold);
        const outOfStock = (products || []).filter(p => p.current_stock === 0);

        reportData = {
          total_products: products?.length || 0,
          total_value: totalValue,
          low_stock_count: lowStock.length,
          out_of_stock_count: outOfStock.length,
          products: products || []
        };

        summary = `Inventory Report: ${products?.length || 0} total products with $${totalValue.toLocaleString()} total value. ${lowStock.length} products are low on stock, ${outOfStock.length} are out of stock.`;
      } else if (reportType === 'sales') {
        const query = supabase
          .from('sales')
          .select('*')
          .eq('status', 'completed');

        if (dateFrom) query.gte('sale_date', dateFrom);
        if (dateTo) query.lte('sale_date', dateTo);

        const { data: sales } = await query;

        const totalRevenue = (sales || []).reduce((sum, s) => sum + s.total_amount, 0);
        const totalUnits = (sales || []).reduce((sum, s) => sum + s.quantity, 0);

        reportData = {
          total_sales: sales?.length || 0,
          total_revenue: totalRevenue,
          total_units: totalUnits,
          avg_order_value: sales?.length ? totalRevenue / sales.length : 0,
          sales: sales || []
        };

        summary = `Sales Report: ${sales?.length || 0} transactions generating $${totalRevenue.toLocaleString()} in revenue. ${totalUnits} units sold with an average order value of $${(reportData.avg_order_value).toFixed(2)}.`;
      } else if (reportType === 'supplier') {
        const { data: suppliers } = await supabase
          .from('suppliers')
          .select('*')
          .eq('is_active', true);

        const avgRating = (suppliers || []).reduce((sum, s) => sum + s.rating, 0) / (suppliers?.length || 1);

        reportData = {
          total_suppliers: suppliers?.length || 0,
          avg_rating: avgRating,
          suppliers: suppliers || []
        };

        summary = `Supplier Report: ${suppliers?.length || 0} active suppliers with an average rating of ${avgRating.toFixed(2)}/5.00.`;
      }

      await supabase.from('reports').insert([{
        report_type: reportType,
        report_name: `${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report`,
        date_from: dateFrom || null,
        date_to: dateTo || null,
        data: reportData,
        summary,
        created_by: user?.id
      }]);

      setReport({ type: reportType, data: reportData, summary, date: new Date().toISOString() });
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Automated Reports</h1>
        <p className="text-gray-400">Generate comprehensive business reports</p>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-white text-lg font-semibold mb-4">Generate New Report</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Report Type</label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="inventory">Inventory Report</option>
              <option value="sales">Sales Report</option>
              <option value="supplier">Supplier Report</option>
            </select>
          </div>

          {reportType === 'sales' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Date From</label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Date To</label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </>
          )}

          <div className="flex items-end">
            <button
              onClick={generateReport}
              disabled={loading}
              className="w-full px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all shadow-lg shadow-blue-600/30 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <FileText className="w-5 h-5" />
              {loading ? 'Generating...' : 'Generate'}
            </button>
          </div>
        </div>
      </div>

      {report && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-green-600/10 p-2 rounded-lg">
                <FileText className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <h3 className="text-white text-lg font-semibold">
                  {report.type.charAt(0).toUpperCase() + report.type.slice(1)} Report
                </h3>
                <div className="flex items-center gap-2 mt-1">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <p className="text-gray-400 text-sm">
                    Generated on {new Date(report.date).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
            <button className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-all flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export
            </button>
          </div>

          <div className="bg-gray-800 rounded-lg p-4 mb-6">
            <h4 className="text-gray-400 text-sm font-medium mb-2">Summary</h4>
            <p className="text-gray-200">{report.summary}</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(report.data).map(([key, value]) => {
              if (Array.isArray(value)) return null;
              return (
                <div key={key} className="bg-gray-800 rounded-lg p-4">
                  <p className="text-gray-500 text-xs uppercase mb-1">
                    {key.replace(/_/g, ' ')}
                  </p>
                  <p className="text-white text-xl font-semibold">
                    {typeof value === 'number' && key.includes('value')
                      ? `$${value.toLocaleString()}`
                      : typeof value === 'number' && key.includes('revenue')
                      ? `$${value.toLocaleString()}`
                      : typeof value === 'number'
                      ? value.toLocaleString()
                      : value}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
