import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Users, Mail, Phone } from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  customer_type: string;
  total_purchases: number;
  created_at: string;
}

export default function CustomersView() {
  const [customers, setCustomers] = useState<Customer[]>([]);

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    const { data } = await supabase
      .from('customers')
      .select('*')
      .order('total_purchases', { ascending: false });

    if (data) {
      setCustomers(data);
    }
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Customers</h1>
        <p className="text-gray-400">Manage your customer relationships</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-blue-600/10 p-2 rounded-lg">
              <Users className="w-5 h-5 text-blue-400" />
            </div>
            <h3 className="text-white font-semibold">Total Customers</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-4">{customers.length}</p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-green-600/10 p-2 rounded-lg">
              <Users className="w-5 h-5 text-green-400" />
            </div>
            <h3 className="text-white font-semibold">Lifetime Value</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-4">
            ${customers.reduce((sum, c) => sum + c.total_purchases, 0).toLocaleString()}
          </p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-purple-600/10 p-2 rounded-lg">
              <Users className="w-5 h-5 text-purple-400" />
            </div>
            <h3 className="text-white font-semibold">Avg Purchase</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-4">
            ${customers.length > 0 ? (customers.reduce((sum, c) => sum + c.total_purchases, 0) / customers.length).toFixed(2) : '0'}
          </p>
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-800 border-b border-gray-700">
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Customer</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Contact</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Type</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Total Purchases</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Since</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {customers.map((customer) => (
              <tr key={customer.id} className="hover:bg-gray-800/50 transition-colors">
                <td className="px-6 py-4">
                  <p className="text-white font-medium">{customer.name}</p>
                </td>
                <td className="px-6 py-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                      <Mail className="w-4 h-4" />
                      {customer.email || 'N/A'}
                    </div>
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                      <Phone className="w-4 h-4" />
                      {customer.phone || 'N/A'}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="px-2.5 py-1 bg-blue-600/10 text-blue-400 rounded-full text-xs font-medium capitalize">
                    {customer.customer_type}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className="text-green-400 font-semibold">
                    ${customer.total_purchases.toLocaleString()}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className="text-gray-400 text-sm">
                    {new Date(customer.created_at).toLocaleDateString()}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
