import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Truck, Star } from 'lucide-react';

interface Supplier {
  id: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  lead_time_days: number;
  rating: number;
  is_active: boolean;
}

export default function SuppliersView() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  useEffect(() => {
    loadSuppliers();
  }, []);

  const loadSuppliers = async () => {
    const { data } = await supabase
      .from('suppliers')
      .select('*')
      .order('rating', { ascending: false });

    if (data) {
      setSuppliers(data);
    }
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Suppliers</h1>
        <p className="text-gray-400">Manage your supplier relationships</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-blue-600/10 p-2 rounded-lg">
              <Truck className="w-5 h-5 text-blue-400" />
            </div>
            <h3 className="text-white font-semibold">Total Suppliers</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-4">{suppliers.length}</p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-green-600/10 p-2 rounded-lg">
              <Truck className="w-5 h-5 text-green-400" />
            </div>
            <h3 className="text-white font-semibold">Active Suppliers</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-4">
            {suppliers.filter(s => s.is_active).length}
          </p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-yellow-600/10 p-2 rounded-lg">
              <Star className="w-5 h-5 text-yellow-400" />
            </div>
            <h3 className="text-white font-semibold">Avg Rating</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-4">
            {suppliers.length > 0
              ? (suppliers.reduce((sum, s) => sum + s.rating, 0) / suppliers.length).toFixed(2)
              : 'N/A'}
          </p>
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-800 border-b border-gray-700">
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Supplier</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Contact</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Lead Time</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Rating</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {suppliers.map((supplier) => (
              <tr key={supplier.id} className="hover:bg-gray-800/50 transition-colors">
                <td className="px-6 py-4">
                  <p className="text-white font-medium">{supplier.name}</p>
                </td>
                <td className="px-6 py-4">
                  <div className="space-y-1">
                    <p className="text-gray-300 text-sm">{supplier.contact_person}</p>
                    <p className="text-gray-500 text-xs">{supplier.email}</p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-gray-300">{supplier.lead_time_days} days</span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="text-white font-semibold">{supplier.rating.toFixed(2)}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                    supplier.is_active
                      ? 'bg-green-600/10 text-green-400'
                      : 'bg-gray-600/10 text-gray-400'
                  }`}>
                    {supplier.is_active ? 'Active' : 'Inactive'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
