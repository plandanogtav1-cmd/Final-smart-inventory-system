/*
  # Populate Sample Data for Testing

  This migration populates the database with realistic sample data for testing and demonstration purposes.

  ## Sample Data Includes:
  1. Suppliers - 5 sample suppliers with contact information
  2. Products - 20 sample products across various categories
  3. Customers - 10 sample customers with purchase history
  4. Sales - 30 sample sales transactions
  5. Forecasts - Sample AI forecasts for top products
  6. Alerts - Sample alerts for low stock items

  This data allows for immediate testing of all system features including:
  - Dashboard analytics
  - Inventory tracking
  - Sales reporting
  - AI chatbot queries
  - Forecasting
*/

-- Insert Sample Suppliers
INSERT INTO suppliers (name, contact_person, email, phone, address, lead_time_days, rating, is_active) VALUES
  ('TechSupply Co', 'John Smith', 'john@techsupply.com', '555-0101', '123 Tech Ave, Silicon Valley, CA', 5, 4.80, true),
  ('Electronics Hub', 'Sarah Johnson', 'sarah@electronichub.com', '555-0102', '456 Circuit Rd, Austin, TX', 7, 4.50, true),
  ('Global Parts Inc', 'Mike Chen', 'mike@globalparts.com', '555-0103', '789 Supply St, New York, NY', 10, 4.90, true),
  ('FastShip Logistics', 'Emma Davis', 'emma@fastship.com', '555-0104', '321 Quick Ln, Chicago, IL', 3, 4.20, true),
  ('Quality Components', 'David Lee', 'david@qualitycomp.com', '555-0105', '654 Parts Blvd, Seattle, WA', 6, 4.70, true)
ON CONFLICT (id) DO NOTHING;

-- Get supplier IDs for reference
DO $$
DECLARE
  supplier1_id uuid;
  supplier2_id uuid;
  supplier3_id uuid;
BEGIN
  SELECT id INTO supplier1_id FROM suppliers WHERE name = 'TechSupply Co' LIMIT 1;
  SELECT id INTO supplier2_id FROM suppliers WHERE name = 'Electronics Hub' LIMIT 1;
  SELECT id INTO supplier3_id FROM suppliers WHERE name = 'Global Parts Inc' LIMIT 1;

  -- Insert Sample Products
  INSERT INTO products (sku, name, description, category, unit_price, cost_price, current_stock, min_stock_threshold, max_stock_threshold, reorder_point, reorder_quantity, supplier_id, is_active) VALUES
    ('ELEC-001', 'Wireless Mouse', 'Ergonomic wireless mouse with USB receiver', 'Electronics', 29.99, 15.00, 150, 20, 500, 30, 100, supplier1_id, true),
    ('ELEC-002', 'Mechanical Keyboard', 'RGB mechanical gaming keyboard', 'Electronics', 89.99, 45.00, 75, 15, 300, 25, 50, supplier1_id, true),
    ('ELEC-003', 'USB-C Cable', 'High-speed USB-C charging cable', 'Electronics', 12.99, 5.00, 8, 50, 1000, 75, 200, supplier2_id, true),
    ('ELEC-004', 'Laptop Stand', 'Adjustable aluminum laptop stand', 'Accessories', 39.99, 20.00, 45, 10, 200, 15, 30, supplier2_id, true),
    ('ELEC-005', 'Webcam HD', '1080p HD webcam with microphone', 'Electronics', 59.99, 30.00, 32, 15, 150, 20, 40, supplier3_id, true),
    ('ELEC-006', 'Phone Charger', 'Fast charging USB wall adapter', 'Electronics', 19.99, 8.00, 200, 40, 800, 60, 150, supplier1_id, true),
    ('ELEC-007', 'Bluetooth Speaker', 'Portable wireless speaker', 'Electronics', 49.99, 25.00, 65, 20, 300, 30, 50, supplier2_id, true),
    ('ELEC-008', 'HDMI Cable', '4K HDMI cable 6ft', 'Electronics', 14.99, 6.00, 120, 30, 500, 45, 100, supplier1_id, true),
    ('ELEC-009', 'Screen Protector', 'Tempered glass screen protector', 'Accessories', 9.99, 3.00, 5, 25, 600, 40, 100, supplier3_id, true),
    ('ELEC-010', 'Phone Case', 'Protective silicone phone case', 'Accessories', 14.99, 5.00, 180, 35, 700, 50, 150, supplier2_id, true),
    ('ELEC-011', 'Power Bank', '20000mAh portable charger', 'Electronics', 34.99, 18.00, 55, 15, 250, 25, 50, supplier1_id, true),
    ('ELEC-012', 'Headphones', 'Noise-cancelling over-ear headphones', 'Electronics', 129.99, 65.00, 28, 10, 150, 15, 30, supplier3_id, true),
    ('ELEC-013', 'Monitor 24"', '24-inch Full HD LED monitor', 'Electronics', 179.99, 90.00, 18, 8, 100, 12, 20, supplier2_id, true),
    ('ELEC-014', 'SSD 500GB', 'External solid state drive', 'Electronics', 79.99, 40.00, 42, 12, 200, 18, 35, supplier1_id, true),
    ('ELEC-015', 'Desk Lamp', 'LED desk lamp with touch control', 'Accessories', 24.99, 12.00, 95, 20, 300, 30, 60, supplier2_id, true),
    ('ELEC-016', 'Cable Organizer', 'Desktop cable management system', 'Accessories', 11.99, 4.00, 140, 30, 500, 45, 100, supplier3_id, true),
    ('ELEC-017', 'Mouse Pad', 'Extended gaming mouse pad', 'Accessories', 16.99, 7.00, 110, 25, 400, 35, 80, supplier1_id, true),
    ('ELEC-018', 'USB Hub', '7-port USB 3.0 hub', 'Electronics', 29.99, 15.00, 68, 15, 250, 22, 45, supplier2_id, true),
    ('ELEC-019', 'Smart Watch', 'Fitness tracking smartwatch', 'Electronics', 199.99, 100.00, 22, 8, 120, 12, 25, supplier3_id, true),
    ('ELEC-020', 'Tablet Stand', 'Adjustable tablet holder', 'Accessories', 19.99, 9.00, 85, 18, 300, 25, 50, supplier1_id, true)
  ON CONFLICT (sku) DO NOTHING;

  -- Insert Sample Customers
  INSERT INTO customers (name, email, phone, address, customer_type, total_purchases) VALUES
    ('Alice Williams', 'alice@email.com', '555-1001', '100 Main St, Boston, MA', 'retail', 0),
    ('Bob Martinez', 'bob@email.com', '555-1002', '200 Oak Ave, Denver, CO', 'wholesale', 0),
    ('Carol Anderson', 'carol@email.com', '555-1003', '300 Pine Rd, Portland, OR', 'retail', 0),
    ('David Thompson', 'david@email.com', '555-1004', '400 Elm St, Miami, FL', 'retail', 0),
    ('Emily Garcia', 'emily@email.com', '555-1005', '500 Maple Dr, Phoenix, AZ', 'wholesale', 0),
    ('Frank Wilson', 'frank@email.com', '555-1006', '600 Cedar Ln, Atlanta, GA', 'retail', 0),
    ('Grace Taylor', 'grace@email.com', '555-1007', '700 Birch Ave, Dallas, TX', 'retail', 0),
    ('Henry Brown', 'henry@email.com', '555-1008', '800 Spruce St, Philadelphia, PA', 'wholesale', 0),
    ('Iris Jones', 'iris@email.com', '555-1009', '900 Willow Rd, San Diego, CA', 'retail', 0),
    ('Jack Miller', 'jack@email.com', '555-1010', '1000 Ash Blvd, Houston, TX', 'retail', 0)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Insert Sample Sales (this will automatically update stock and trigger alerts)
DO $$
DECLARE
  product_rec RECORD;
  customer_rec RECORD;
  sale_date timestamptz;
  i integer;
BEGIN
  -- Create sales over the past 30 days
  FOR i IN 1..30 LOOP
    sale_date := now() - (i || ' days')::interval;
    
    -- Get random products and customers
    FOR product_rec IN (SELECT id, unit_price FROM products ORDER BY random() LIMIT 3) LOOP
      FOR customer_rec IN (SELECT id FROM customers ORDER BY random() LIMIT 1) LOOP
        INSERT INTO sales (product_id, customer_id, quantity, unit_price, total_amount, sale_date, payment_method, status)
        VALUES (
          product_rec.id,
          customer_rec.id,
          (FLOOR(random() * 5) + 1)::integer,
          product_rec.unit_price,
          product_rec.unit_price * (FLOOR(random() * 5) + 1),
          sale_date,
          CASE FLOOR(random() * 3)
            WHEN 0 THEN 'cash'
            WHEN 1 THEN 'credit_card'
            ELSE 'debit_card'
          END,
          'completed'
        );
      END LOOP;
    END LOOP;
  END LOOP;
END $$;